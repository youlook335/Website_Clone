

    // image.addEventListner("click", function(){
    //     console.log("clock ok ha");
    //     console.log("Ok ha ");
    // image.style.display = 'none';
    // video.style.display = 'block';

    // video.play();
    // });


    function playfunc(){
        let image = document.querySelectorAll(".thumbnail");
        let video = document.querySelectorAll(".video");

        console.log("click");
        // image.forEach((image) => {
        //     image.hidden = true; 
        // });

        image.hidden = true;
    
        // video.forEach((video) => {
        //     video.hidden = false;
        //     video.play(); 
        // });

        video.hidden = false;
        video.play();
    }



    
function searchVideos(){
    let search = document.getElementById("search");
    let contents = document.querySelectorAll(".content-1");

       
    }
